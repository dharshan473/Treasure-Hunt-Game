function initialise(){

	var obj = new Game();
}


function Game(){

	//start timer
	//generate map
	//assign first treasure to map
	//score reset to 0
	const startmin = 3;
	let time = startmin * 60;

	const countdown = document.getElementById("timer");
	let refresh = setInterval(update,1000);

	function update(){
		let minutes = Math.floor(time/60);

		let seconds = time%60;

		seconds = seconds < 10 ? '0' + seconds : seconds;
		countdown.innerHTML = `${minutes}:${seconds}`;
		time--;
		if(time < 0){
			clearInterval(refresh);
			timeover();
		}
	}

	var score = 0;
	var lives = 5;

	//when timer reaches 0
	//display game over message
	var startBtn = document.getElementById("start-button");
	var reset = document.getElementById("reset-button");

	
	var fsub = document.getElementById("submitform");
	fsub.style.display = "none";

	startBtn.style.display = "none";
	reset.style.display= "none";
	let health = document.getElementById("health");
	health.value = 10;

	document.getElementById("demo3").innerHTML = score;
	document.getElementById("demo4").innerHTML = "";
	document.getElementById("rules").innerHTML = "";

	var previousgameover = document.getElementById("gameover");

		if(previousgameover){
			previousgameover.remove();
		}

	var gameover = document.createElement("p");
	gameover.id = "gameover";
	gameover.className = "col-sm-12 col-md-12 col-lg-12";
	document.getElementById("board").appendChild(gameover);

	document.getElementById("gameover").innerHTML = "";

	//initialise treasure coordinates
	var x;
	var y;

	var clues = ['A2','B2','C3', 'C4','D3','E3']; //[1,1  2,3  3,3  3,4  4,5  5,4   5,3]
	var hints = ["row: I'm neither prime nor composite <br> col: X is the number of traingles in the given figure column number is X/8 <br> <img src='traingle.png'>",
				"One morning after sunrise, Suresh was standing facing a pole. The shadow of the pole fell exactly to his right. To which direction was he facing?",
				"row: How many primary colors are there in traditional color theory? <br> col: X is the next number in the series 31, 29, 24, 22, 17,....  column no is X/5",
				"Go to the direction in which sun rises",
				"A man walks 5 km toward south and then turns to the right. After walking 3 km he turns to the left and walks 5 km. Now in which direction is he from the starting place?",
				"<br><img src='giphy.gif' width='100px' height='100px'>"
				]

	var c = 0;

	var map = [
		['A1', 'A2', 'A3', 'A4', 'A5'],
		['B1', 'B2', 'B3', 'B4', 'B5'],
		['C1', 'C2', 'C3', 'C4', 'C5'],
		['D1', 'D2', 'D3', 'D4', 'D5'],
		['E1', 'E2', 'E3', 'E4', 'E5']
		];
	
		
	
	function renderMap(){

		var previousgame = document.getElementById("game");

		if(previousgame){
			previousgame.remove();
		}

		var game = document.createElement("div");
		game.id = "game";
		game.className = "col-sm-12 col-md-12 col-lg-12";
		document.getElementById("board").appendChild(game);

		// loop the outer array
		
		for (var i = 0; i < map.length; i++) {
			// get the size of the inner array
			var innerArrayLength = map[i].length;
			// loop the inner array
			for (var j = 0; j < innerArrayLength; j++) {
				console.log('[' + i + ',' + j + '] = ' + map[i][j]);
				var btn = document.createElement("BUTTON");        // Create a <button> element
				btn.className = "game-button";
				btn.id = map[i][j];
				
				btn.onclick = checkTreasure;
				
				
				//var t = document.createTextNode(map[i][j]);       // Create a text node
				//btn.appendChild(t);                                // Append the text to <button>
				document.getElementById("game").appendChild(btn);

				var isMultipleof4 = function (n) 
				{ 
					if ( n == 0 ){ 
						return false; 
					}
					else{
						while ( n > 0 )
						{ 
							n = n - 4; 
						  }

						if ( n == 0 ){ 
							return true; 
						  }
						  else{
							return false;
						}
					} 
				}
				
				if ( isMultipleof4(j) == true ){
					var br = document.createElement("div");
					br.className = "clear";
					document.getElementById("game").appendChild(br);
				}
			}
		}
		document.getElementById('hint').innerHTML = hints[0];
	}
	
	function assignTreasure(){
		var m = new renderMap();
		x = 2;
		y = 3;
		x1 = 4;
		y1 = 2;
		//document.getElementById("demo").innerHTML = "Current Treasure: " + map[x][y];
		//document.getElementById("demo5").innerHTML = "X: " + x + " Y: " + y;
		
	}
	function timeover(){
		document.getElementById("demo4").innerHTML = "Time up";
		document.getElementById("demo4").style.color = "red";
		reset.style.display = "block";
		document.getElementById("game").remove();
		fsub.style.display = "block";
	}
	assignTreasure();
	
	function checkLives(){
		lives = lives - 1;

		if(lives == 0){
				document.getElementById("game").remove();
				clearInterval(refresh);
				document.getElementById("gameover").innerHTML = "GAME OVER";
				document.getElementById("gameover").style.color = "#E74646";
				document.getElementById("demo3").innerHTML = score;

				
				
				
				
				health.value -= 2;
				
				
				startBtn.style.display = "none";
				reset.style.display = "block";
				fsub.style.display = "block";
				
				
			}
			else{
				health.value -= 2;
			}
			 
	}
	
	var f = 0;
	function checkTreasure(){

		console.log(lives);
		//if coordinates of this button equals cocordinates of current treasure
		//then increase player's score
		//update score and or how close to treasure

		//if clicked button is hiding the treasure 
		if(this.id == map[x][y]){
			c++;
			document.getElementById('hint').innerHTML = hints[c];
			score = score + 1000;
			document.getElementById("demo3").innerHTML = score;
			document.getElementById("demo4").innerHTML = "Great! you have found the first Treasure!";
			document.getElementById("demo4").style.color = "green";
			this.style.backgroundColor = "green";
			
			f = 1;
			//assign another treasure to different location
			//document.getElementById("game").remove();
			//assignTreasure();
			//checkLives();
			//document.getElementById('hint').innerHTML = "";
		}
		else if(this.id == map[x1][y1] && f == 1){
			score = score + 1000;
			document.getElementById("demo3").innerHTML = score;
			document.getElementById("demo4").innerHTML = "Success! you have Found all the hidden Treasure!";
			document.getElementById("demo4").style.color = "green";
			document.getElementById("game").remove();
			//assignTreasure();
			//checkLives();
			clearInterval(refresh);
			document.getElementById('hint').innerHTML = "";
			fsub.style.display = "block";


		}
		//else if clicked button is close to treasure
		else
		{ 
				/*var a = map.length;
				//var b = map[a].length;

				//control variables incase they go out of range of array
				var xplus = x + 1; if(xplus == a){ xplus = a - 1;}
				var xminus = x - 1; if(xminus == -1){ xminus = 0;}
				var yplus = y + 1; if(yplus == a){ yplus = a - 1;}
				var yminus = y - 1; if(yminus == -1){ yminus = 0;}
				
				//specify how close the clicked button is to the treasure  
				  var topleft = map[xminus][yminus];
				var topmid = map[xminus][y];
				var topright = map[xminus][yplus];
				var midleft = map[x][yminus];
				var midright = map[x][yplus];
				var bottomleft = map[xplus][yminus];
				var bottommid = map[xplus][y];
				var bottomright = map[xplus][yplus];

				  if(this.id == topleft || 
					  this.id == topmid ||
					  this.id == topright ||
					  this.id == midleft ||
					  this.id == midright ||
					  this.id == bottomleft ||
					  this.id == bottommid ||
					  this.id == bottomright )
				  {
					  document.getElementById("demo4").innerHTML = "You are warm.";
					  document.getElementById("demo4").style.color = "orange"
					this.style.backgroundColor = "#F5B461";
					this.disabled = true;
					
					checkLives();
				  }*/
				  

				  
				if(this.id == clues[c]){
					c++;
					score += 100;
					document.getElementById("demo3").innerHTML = score;
					document.getElementById("demo4").innerHTML = "Great!... keep going";
					this.style.backgroundColor = "#F5B461";
					document.getElementById("demo4").style.color = "#F7DB6A";
					document.getElementById('hint').innerHTML = hints[c];

				}
				else{
					
					document.getElementById('hint').innerHTML = hints[c];
					document.getElementById("demo4").innerHTML = "wrong answer... try again";
					document.getElementById("demo4").style.color = "#E74646";
					this.style.backgroundColor = "#E74646";
					this.disabled = true;
					checkLives();
					reset.style.display = "block";
					
				}
				
		  } 

			  
	}
			

			
			
			
		
		 
	

}